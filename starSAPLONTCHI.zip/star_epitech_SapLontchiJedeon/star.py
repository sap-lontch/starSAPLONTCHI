taille = int(input("entrez la taille de l'etoile"))
if (taille == 0):
    print('vous avez entre 0')
else:
    for i in range(0, taille):
        for j in range(0, (2 * taille - i) + taille):
            print(end=" ")
        if i == 0:
            print("*")
        else:
            print(end="*")
            for s in range(0, i * 2 - 1):
                print(end=" ")
            print("*")
    for k in range(0, (taille * 2) + 1):
        print(end="*")
    for s in range(0, taille * 2 - 1):
        print(end=" ")
    for k in range(0, (taille * 2) + 1):
        print(end="*")
    print()
    for i in range(0, taille):
        for j in range(0, (taille + i) - (taille - 1)):
            print(end=" ")
        print(end="*")
        for s in range(0, 6 * taille - 3 - (2 * i)):
            print(end=" ")
        print("*")
    for i in range(0, taille - 1):
        for j in range(0, (2 * taille - i) - taille - 1):
            print(end=" ")
        print(end="*")
        for s in range(0, 5 * taille + 1 - (taille - 2 * i)):
            print(end=" ")
        print("*")
    for k in range(0, (taille * 2) + 1):
        print(end="*")
    for s in range(0, taille * 2 - 1):
        print(end=" ")
    for k in range(0, (taille * 2) + 1):
        print(end="*")
    print()
    for i in range(0, taille):
        for j in range(0, (2 * taille + i) + 1):
            print(end=" ")
        if i == taille - 1:
            print("*")
        else:
            print(end="*")
            for s in range(0, taille * 2 - 1 - i * 2 - 2):
                print(end=" ")
            print("*")
